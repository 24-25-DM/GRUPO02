const vehiculos = [];

export default vehiculos;