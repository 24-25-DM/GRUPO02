const integrantes = [
    
];

export default integrantes;